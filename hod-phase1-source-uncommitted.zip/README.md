# Haus of Dink Phase 1 foundation (uncommitted)

These are additive foundation files only. They do NOT implement CRUD mutations,
database-boundary authorization for writes, audit logging, or admin UI.

Copy `src/server/catalog` into the repository after checking for collisions.
Do not interpret successful preflight checks as mutation authorization.

Run:
npm run typecheck
npm run lint
npm run auth:test
npm run db:test
npm run inventory:test
npm run db:check
npm run build

Before Phase 2: implement atomic SQL mutations using currentPermissionSessionConditions
and managementLock, and verify migrations against the target Neon database.

Focused validation tests (not wired into package.json automatically):
node --import tsx --test scripts/catalog-contracts.test.ts

Not covered by this package: duplicate SKU/barcode integration checks, active
reference and revoked-session integration tests, full CRUD, or transactional
mutation authorization. These require running against the actual repository.
