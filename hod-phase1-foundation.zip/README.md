# Haus of Dink Phase 1 foundation (uncommitted)

These are additive foundation files only. They do NOT implement CRUD mutations,
database-boundary authorization for writes, audit logging, or admin UI.

Copy `src/server/catalog` into the repository after checking for collisions.
Do not interpret successful preflight checks as mutation authorization.

Run:
npm run typecheck
npm run lint
npm run auth:test
npm run db:test
npm run inventory:test
npm run db:check
npm run build

Before Phase 2: implement atomic SQL mutations using currentPermissionSessionConditions
and managementLock, and verify migrations against the target Neon database.
